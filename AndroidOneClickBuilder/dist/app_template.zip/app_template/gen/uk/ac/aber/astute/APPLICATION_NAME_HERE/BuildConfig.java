/** Automatically generated file. DO NOT MODIFY */
package uk.ac.aber.astute.APPLICATION_NAME_HERE;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}